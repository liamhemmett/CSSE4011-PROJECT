#include "lib/HCI.h"
// #include "lib/dac_lib.h"
#include "lib/led_lib.h"
#include "lib/process.h"
#include "lib/push_button.h"
#include "lib/sd_writer.h"
#include <math.h>
#include <stdbool.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>

char draw_msgq_buffer[10 * sizeof(draw_params_t)];
struct k_thread uart_polling_thread_data;
struct k_thread worker_thread_data;

#define UART_POLLING_THREAD_STACK_SIZE 2048
#define WORKER_THREAD_STACK_SIZE 1024

K_SEM_DEFINE(button_sem, 0, 2);

K_THREAD_STACK_DEFINE(uart_polling_stack, UART_POLLING_THREAD_STACK_SIZE);
K_THREAD_STACK_DEFINE(worker_stack, WORKER_THREAD_STACK_SIZE);

int main(void) {
  printk("Successfully config button and leds\n");
  if (!led_init()) {
    printk("LED init failed \n");
    return -1;
  }
  toggle_led0();
  if (!button_init()) {
    printk("push button init failed \n");
    return -1;
  }
  if (dac_init() != 1) {
    printk("DAC init failed \n");
    return -1;
  }
  k_sem_init(&button_sem, 0, 1);
  if (!sd_card_init()) {
    printk("SD init failed \n");
    return -1;
  }
  printk("Thread start");
  // Start the UART polling thread
  k_thread_create(&uart_polling_thread_data, uart_polling_stack,
                  K_THREAD_STACK_SIZEOF(uart_polling_stack),
                  uart_polling_thread, NULL, NULL, NULL, 7, 0, K_NO_WAIT);

  k_thread_create(&worker_thread_data, worker_stack,
                  K_THREAD_STACK_SIZEOF(worker_stack), worker_thread_function,
                  NULL, NULL, NULL, 7, 0, K_NO_WAIT);

  while (1) {
    k_sleep(K_MSEC(1000));
  }
  return -1;
}
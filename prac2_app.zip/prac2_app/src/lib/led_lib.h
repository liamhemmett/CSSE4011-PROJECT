#ifndef LED_LIB_H
#define LED_LIB_H

#include <math.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>

// Define nodes for each LED using device tree aliases.
#define LED0_NODE DT_ALIAS(led0)
#define LED1_NODE DT_ALIAS(led1)
#define LED2_NODE DT_ALIAS(led2)

// Declare gpio_dt_spec for each LED to abstract pin configuration.
extern const struct gpio_dt_spec led0;
extern const struct gpio_dt_spec led1;
extern const struct gpio_dt_spec led2;

// Toggle the state of LED0.
void toggle_led0();

// Toggle the state of LED1.
void toggle_led1();

// Toggle the state of LED2.
void toggle_led2();

int led_init();

#endif // LED_LIB_H

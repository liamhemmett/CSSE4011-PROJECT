#ifndef PROCESS_H
#define PROCESS_H

#include "HCI.h"
#include "dac_lib.h"
#include "led_lib.h"
#include <math.h>
#include <stdbool.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>

#define MAX_DRAW_COMMANDS 10

#define GRAPH 1
#define METER 2
#define NUMERIC 3
#define TEMP 5
#define HUMID 6
#define AIR 7
#define TVOC 8
#define SD 13


/**
 * Function to be executed by the worker thread.
 * This function processes drawing commands sent to the message queue.
 *
 */
void worker_thread_function(void *arg1, void *arg2, void *arg3);

/**
 * Function to be executed by the UART polling thread.
 * This function continuously checks for incoming data over UART and
 * converts received messages into drawing commands.
 *
 */
void uart_polling_thread(void *arg1, void *arg2, void *arg3);

#endif // PROCESS_H

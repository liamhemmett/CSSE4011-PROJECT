#ifndef HCI_H_
#define HCI_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/kernel.h>
#include <zephyr/shell/shell.h>


// Define USART2 device tree node label for UART communication.
#define MY_USART2 DT_NODELABEL(usart3)



// Communication protocol constants.
#define PREAMBLE 0xAA // Preamble byte indicating the start of a message.
#define REQUEST 0x01  // Identifier for request messages.
#define RESPONSE 0x02 // Identifier for response messages.
#define END 0x55      // End byte indicating the end of a message.

// Device Identifier (DID) for different peripherals.
#define LED_DID 1 // Device ID for LED.
#define PB_DID 2  // Device ID for Push Button.
#define DAC_ID 3  // Device ID for Digital to Analog Converter.
#define LCP 4

#define MSG_SIZE 34

extern struct k_msgq uart_msgq; 

static const struct device *const uart_dev = DEVICE_DT_GET(MY_USART2);
/**
 * Sends a request with the specified data.
 * @param data The data byte to be sent in the request.
 */
void send_request(char *str);

/**
 * Receives a request and returns the received data as a string.
 * @return A pointer to a string containing the received data.
 */
void serial_cb(const struct device *dev, void *user_data);


#endif // HCI_H_

#ifndef BUTTON_H
#define BUTTON_H
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>

#define SW0_NODE DT_ALIAS(sw0)
#if !DT_NODE_HAS_STATUS(SW0_NODE, okay)
#error "Unsupported board: sw0 devicetree alias is not defined"
#endif

static const struct gpio_dt_spec button = GPIO_DT_SPEC_GET(SW0_NODE, gpios);
static struct gpio_callback button_cb_data __attribute__((unused));

//init push button
int button_init();

//push button pressed interupt
void button_pressed(const struct device *dev, struct gpio_callback *cb,
                    uint32_t pins);
#endif
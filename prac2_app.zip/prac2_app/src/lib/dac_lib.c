#include "dac_lib.h"
#include "led_lib.h"
const struct device *dac_dev_1 = DEVICE_DT_GET(DAC_NODE_1);
const struct device *dac_dev_2 = DEVICE_DT_GET(DAC_NODE_2);

K_MSGQ_DEFINE(draw_msgq, sizeof(draw_params_t), NUM_STRINGS, 4);

/**
 * Initializes DAC devices.
 *
 * This function initializes two DAC devices for use in drawing operations.
 * It verifies the readiness of each DAC device and sets up the necessary DAC
 * channels.
 *
 * @return int Returns 1 if initialization is successful, -1 otherwise.
 */
int dac_init() {
  dac_dev_1 = DEVICE_DT_GET(DAC_NODE_1);
  dac_dev_2 = DEVICE_DT_GET(DAC_NODE_2);

  if (!device_is_ready(dac_dev_1) || !device_is_ready(dac_dev_2)) {
    printk("DAC device(s) not ready\n");
    return -1;
  }

  if (setup_dac_channel(dac_dev_1, DAC_CHANNEL_ID_1) != 0) {
    printk("Failed to setup DAC channel 1\n");
    return -1;
  }

  if (setup_dac_channel(dac_dev_2, DAC_CHANNEL_ID_2) != 0) {
    printk("Failed to setup DAC channel 2\n");
    return -1;
  }
  return 1;
}

/**
 * Configures a DAC channel.
 *
 * Sets up a specific channel of a DAC device with predefined configuration
 * settings.
 *
 * @param dac_dev The DAC device instance.
 * @param channel_id The ID of the DAC channel to configure.
 * @return int Returns 0 on success, non-zero error code on failure.
 */
int setup_dac_channel(const struct device *dac_dev, uint8_t channel_id) {
  struct dac_channel_cfg cfg = {
      .channel_id = channel_id,
      .resolution = DAC_RESOLUTION,
      .buffered = true,
  };
  return dac_channel_setup(dac_dev, &cfg);
}

/**
 * Draws a point on the display using DAC output.
 *
 * This function converts x and y values to corresponding DAC values and
 * writes them to the configured DAC channels to draw a point.
 *
 * @param x_val The x-coordinate of the point.
 * @param y_val The y-coordinate of the point.
 */
void draw_point(float x_val, float y_val) {

  int x = MAX_VALUE * x_val / 3.3f;
  int y = MAX_VALUE * y_val / 3.3f;
  dac_write_value(dac_dev_1, DAC_CHANNEL_ID_1, x);
  dac_write_value(dac_dev_2, DAC_CHANNEL_ID_2, y);
}

/**
 * Draws a meter on the display.
 *
 * This function draws a semicircular meter and a pointer indicating the current
 * value.
 *
 * @param min The minimum value the meter can display.
 * @param max The maximum value the meter can display.
 * @param value The current value to display on the meter.
 */
void draw_meter(float min, float max, float value) {
  draw_params_t params;
  float radius =
      1.6f; // Half of 3.3V to fit the semicircle within the DAC output range
  float x_offset = 1.65f; // Center the semicircle on the X-axis
  float y_offset = 0.1f;  // Align the semicircle bottom with the Y-axis minimum
  float angle, x_val, y_val;
  while (k_msgq_peek(&draw_msgq, &params)) {

    // Draw semicircle
    for (angle = 0; angle <= M_PI; angle += 0.01f) {
      x_val = radius * cosf(angle) + x_offset;
      y_val = radius * sinf(angle) + y_offset;
      if (y_val < 0 || x_val < 0) {
        continue;
      }
      draw_point(x_val, y_val);
    }
    draw_point(x_offset, y_offset);
    // Calculate value position on semicircle
    float value_normalized =
        (value - min) / (max - min); // Normalize value to [0, 1]
    float value_angle =
        M_PI - (value_normalized *
                M_PI); // Invert mapping: Map normalized value to [PI, 0]

    float line_end_x = (radius - 0.2f) * cosf(value_angle) + x_offset;
    float line_end_y = (radius - 0.2f) * sinf(value_angle) + y_offset;

    // Draw line from center to value
    draw_line(x_offset, y_offset, line_end_x, line_end_y);

    k_sleep(K_USEC((int)(1)));
  }
}

/**
 * Draws a line between two points.
 *
 * This function interpolates points between the start and end coordinates
 * and uses draw_point to render a line on the display.
 *
 * @param x_start The x-coordinate of the start point.
 * @param y_start The y-coordinate of the start point.
 * @param x_end The x-coordinate of the end point.
 * @param y_end The y-coordinate of the end point.
 */
void draw_line(float x_start, float y_start, float x_end, float y_end) {
  float dx = x_end - x_start;
  float dy = y_end - y_start;
  float steps = 1000.0f;
  float x_inc = dx / steps;
  float y_inc = dy / steps;
  float x = x_start;
  float y = y_start;

  for (int i = 0; i <= steps; i++) {
    if (x < 0 || y < 0) {
      continue;
    }
    draw_point(x, y); // Scale points to DAC range
    x += x_inc;
    y += y_inc;
  }
  draw_point(x_start, y_start);
}

/**
 * Draws a segment of a digital number.
 *
 * Uses draw_line to render individual segments of a digital number at a
 * specified location.
 *
 * @param segment The segment character ('A'-'G') to draw.
 * @param base_x The x-coordinate of the base position for the number.
 * @param base_y The y-coordinate of the base position for the number.
 */
void draw_segment(char segment, float base_x, float base_y) {
  switch (segment) {
  case 'A':
    draw_line(base_x, base_y + 2.0f * SEGMENT_LENGTH, base_x + SEGMENT_LENGTH,
              base_y + 2.0f * SEGMENT_LENGTH);
    break;
  case 'B':
    draw_line(base_x + SEGMENT_LENGTH, base_y + 2.0f * SEGMENT_LENGTH,
              base_x + SEGMENT_LENGTH, base_y + SEGMENT_LENGTH);
    break;
  case 'C':
    draw_line(base_x + SEGMENT_LENGTH, base_y + SEGMENT_LENGTH,
              base_x + SEGMENT_LENGTH, base_y);
    break;
  case 'D':
    draw_line(base_x, base_y, base_x + SEGMENT_LENGTH, base_y);
    break;
  case 'E':
    draw_line(base_x, base_y + SEGMENT_LENGTH, base_x, base_y);
    break;
  case 'F':
    draw_line(base_x, base_y + 2.0f * SEGMENT_LENGTH, base_x,
              base_y + SEGMENT_LENGTH);
    break;
  case 'G':
    draw_line(base_x, base_y + SEGMENT_LENGTH, base_x + SEGMENT_LENGTH,
              base_y + SEGMENT_LENGTH);
    break;
  }
}

// Mapping of digits to segments
char *digit_to_segments[10] = {
    "ABCEFD",  // 0
    "BC",      // 1
    "ABDGE",   // 2
    "ABCDG",   // 3
    "BCFG",    // 4
    "ACDFG",   // 5
    "ACDEFG",  // 6
    "ABC",     // 7
    "ABCDEFG", // 8
    "ABCFG",   // 9
};

/**
 * Draws a numerical digit at a specified location.
 *
 * @param num The number to draw (0-9).
 * @param x The x-coordinate of the location to draw the number.
 * @param y The y-coordinate of the location to draw the number.
 */
void draw_number(int num, float x, float y) {
  if (num < 0 || num > 9)
    return;

  char *segments = digit_to_segments[num];

  for (int i = 0; segments[i] != '\0'; i++) {
    draw_segment(segments[i], x, y);
  }
}

/**
 * Draws a series of numbers.
 *
 * This function iterates through an array of numbers and uses draw_number
 * to render each one at a specific interval along the x-axis.
 *
 * @param numbers The array of numbers to draw.
 * @param count The number of elements in the numbers array.
 */
void draw_series(int numbers[], int count) {
  float startY = 1.0;
  draw_params_t params;
  while (k_msgq_peek(&draw_msgq, &params)) {
    draw_point(6 * (SEGMENT_LENGTH + 0.155f), 1.0f);
    draw_point(6 * (SEGMENT_LENGTH + 0.150f), 1.0f);
    draw_point(6 * (SEGMENT_LENGTH + 0.16f), 1.0f);
    for (int i = 0; i < count; i++) {
      draw_number(numbers[i], i * (SEGMENT_LENGTH + 0.1f), startY);
    }
    k_sleep(K_USEC((int)(1)));
  }
}

/**
 * Draws a graph of values.
 *
 * Renders a simple line graph based on an array of values. The graph is drawn
 * from right to left.
 *
 * @param values The array of values to graph.
 * @param count The number of elements in the values array.
 */
void draw_graph(float values[], int count) {
  draw_params_t params;
  while (k_msgq_peek(&draw_msgq, &params)) {
    draw_line(0, 0, 0, 3.3);
    draw_line(0, 0, 3.3, 0);
    draw_point(3.3, 0);
    draw_line(3.3, 0, 3.3, 0);
    for (int i = 0; i < count; i++) {
      draw_point(3.1 - i * 3.3 / count, values[i]);
      k_sleep(K_USEC((int)(1)));
    }
    draw_point(0, 0);
    k_sleep(K_USEC((int)(1)));
  }
}

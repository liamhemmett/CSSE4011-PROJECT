#include "process.h"
#include "HCI.h"
#include "dac_lib.h"
#include "led_lib.h"
#include "sd_writer.h"
#include <math.h>
#include <stdbool.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>

/**
 * Function to be executed by the worker thread.
 * This function processes drawing commands sent to the message queue.
 *
 */
void worker_thread_function(void *arg1, void *arg2, void *arg3) {
  draw_params_t params;
  static float air_values[10];
  static float temp_values[10];
  static float humid_values[10];
  static float tvoc_values[10];
  while (true) {

    if (k_msgq_get(&draw_msgq, &params, K_FOREVER) == 0) {

      if (params.command == DRAW_METER) {
        if (params.type == TYPE_HUMID) {
          float meter_value;
          if (params.data_value > 100.0f) {
            meter_value = 100.0f;
          } else if (params.data_value < 0.0f) {
            meter_value = 0.0f;
          } else {
            meter_value = params.data_value;
          }
          draw_meter(0.0f, 100.0f, meter_value);
        } else if (params.type == TYPE_AIR) {
          float meter_value;
          if (params.data_value > 150.0f) {
            meter_value = 150.0f;
          } else if (params.data_value < 50.0f) {
            meter_value = 50.0f;
          } else {
            meter_value = params.data_value;
          }
          draw_meter(50.0f, 150.0f, meter_value);
        } else if (params.type == TYPE_TVOC) {
          float meter_value;
          if (params.data_value > 1186.0f) {
            meter_value = 1186.0f;
          } else if (params.data_value < 0.0f) {
            meter_value = 0.0f;
          } else {
            meter_value = params.data_value;
          }
          draw_meter(0.0f, 1186.0f, meter_value);
        } else if (params.type == TYPE_TEMP) {
          float meter_value;
          if (params.data_value > 50.0f) {
            meter_value = 50.0f;
          } else if (params.data_value < 0.0f) {
            meter_value = 0.0f;
          } else {
            meter_value = params.data_value;
          }
          draw_meter(0.0f, 50.0f, meter_value);
        } else {
          printk("GRAPH READ");
          continue;
        }

      } else if (params.command == DRAW_GRAPH) {
        if (params.type == TYPE_HUMID) {
          float meter_value;
          if (params.data_value > 100.0f) {
            meter_value = 100.0f;
          } else if (params.data_value < 0.0f) {
            meter_value = 0.0f;
          } else {
            meter_value = params.data_value;
          }
          float graph_point = meter_value / 100.0f * 3.3f;
          for (int i = 0; i < 9; i++) {
            air_values[i] = humid_values[i + 1];
          }
          humid_values[0] = graph_point;
          draw_graph(humid_values, 10);
        } else if (params.type == TYPE_AIR) {
          float meter_value;
          if (params.data_value > 150.0f) {
            meter_value = 150.0f;
          } else if (params.data_value < 50.0f) {
            meter_value = 50.0f;
          } else {
            meter_value = params.data_value;
          }

          float graph_point = meter_value / 150.0f * 3.3f;
          for (int i = 0; i < 9; i++) {
            air_values[i] = air_values[i + 1];
          }
          air_values[0] = graph_point;
          draw_graph(air_values, 10);
        } else if (params.type == TYPE_TVOC) {
          float meter_value;
          if (params.data_value > 1186.0f) {
            meter_value = 1186.0f;
          } else if (params.data_value < 0.0f) {
            meter_value = 0.0f;
          } else {
            meter_value = params.data_value;
          }
          float graph_point = meter_value / 1186.0f * 3.3f;
          for (int i = 0; i < 9; i++) {
            tvoc_values[i] = tvoc_values[i + 1];
          }
          tvoc_values[0] = graph_point;
          draw_graph(tvoc_values, 10);
        } else if (params.type == TYPE_TEMP) {
          float meter_value;
          if (params.data_value > 50.0f) {
            meter_value = 50.0f;
          } else if (params.data_value < 0.0f) {
            meter_value = 0.0f;
          } else {
            meter_value = params.data_value;
          }
          float graph_point = meter_value / 50.0f * 3.3f;
          for (int i = 0; i < 9; i++) {
            temp_values[i] = temp_values[i + 1];
          }

          temp_values[0] = graph_point;
          draw_graph(temp_values, 7);
        } else {
          printk("draw read");
          continue;
        }
      } else if (params.type == (type_command_t)DRAW_NUM) {

        int numbers[8] = {0,
                          0,
                          params.values[0],
                          params.values[1],
                          params.values[2],
                          params.values[3],
                          params.values[4],
                          params.values[5]};

        draw_series(numbers, 8);
      }
    }
    k_sleep(K_MSEC((int)(1)));
  }
}

/**
 * Function to be executed by the UART polling thread.
 * This function continuously checks for incoming data over UART and
 * converts received messages into drawing commands.
 *
 */
void uart_polling_thread(void *arg1, void *arg2, void *arg3) {

  struct uart_config uart_cfg = {
      .baudrate = 9600,
      .parity = UART_CFG_PARITY_NONE,
      .stop_bits = UART_CFG_STOP_BITS_1,
      .flow_ctrl = UART_CFG_FLOW_CTRL_NONE,
      .data_bits = UART_CFG_DATA_BITS_8,
  };
  uart_configure(uart_dev, &uart_cfg);
  char tx_buf[MSG_SIZE];

  if (!device_is_ready(uart_dev)) {
    printk("UART device not found!");
    return;
  }

  /* configure interrupt and callback to receive data */
  int ret = uart_irq_callback_user_data_set(uart_dev, serial_cb, (void *)NULL);

  if (ret < 0) {
    if (ret == -ENOTSUP) {
      printk("Interrupt-driven UART API support not enabled\n");
    } else if (ret == -ENOSYS) {
      printk("UART device does not support interrupt-driven API\n");
    } else {
      printk("Error setting UART callback: %d\n", ret);
    }
    return;
  }
  uart_irq_rx_enable(uart_dev);

  bool recording = false;
  char filename[11];
  char data[9];
  printk("\nWating \n");
  /* indefinitely wait for input from the user */
  while (k_msgq_get(&uart_msgq, &tx_buf, K_FOREVER) == 0) {
    printk("got\n");
    draw_params_t draw_params;
    if (tx_buf[1] == GRAPH) {
      draw_params.command = DRAW_GRAPH;

    } else if (tx_buf[1] == METER) {
      draw_params.command = DRAW_METER;

    } else if (tx_buf[1] == NUMERIC) {
      draw_params.command = DRAW_NUM;

    } else if (tx_buf[1] == SD) {
      if (tx_buf[2] == 0xA7) {
        for (int i = 0; i < 9; i++) {

          filename[i] = tx_buf[i + 3];
        }
        filename[9] = '\0';
        printk("setting filename: %s\n ", filename);
        continue;
      } else if (tx_buf[2] == 0xA9) {
        printk("data write\n");
        for (int i = 0; i < 6; i++) {

          data[i] = tx_buf[i + 3];
        }
        data[5] = data[4];
        data[6] = data[5];
        data[4] = 0x2E;
        data[7] = '\0';

        printk("recording data: %s\n ", data);
        printk("recording filename: %s\n ", filename);
        printk("recording date: %lld\n ", k_cycle_get_64());
        sd_write_csv_line(k_cycle_get_64(), data, filename);
        printk("data write done\n");
        continue;
      }

    } else {
      printk("invalid plot type");
    }

    if (recording) {
    }

    if (tx_buf[2] == TEMP) {
      draw_params.type = TYPE_TEMP;
    } else if (tx_buf[2] == HUMID) {
      draw_params.type = TYPE_HUMID;
    } else if (tx_buf[2] == TVOC) {
      draw_params.type = TYPE_TVOC;
    } else if (tx_buf[2] == AIR) {
      draw_params.type = TYPE_AIR;

    } else {
      printk("invalid sensor type");
    }

    draw_params.values[0] = tx_buf[3] & 0x0F;
    draw_params.values[1] = tx_buf[4] & 0x0F;
    draw_params.values[2] = tx_buf[5] & 0x0F;
    draw_params.values[3] = tx_buf[6] & 0x0F;
    draw_params.values[4] = tx_buf[7] & 0x0F;
    draw_params.values[5] = tx_buf[8] & 0x0F;

    int value_int = draw_params.values[0] * 100000 +
                    draw_params.values[1] * 10000 +
                    draw_params.values[2] * 1000 + draw_params.values[3] * 100 +
                    draw_params.values[4] * 10 + draw_params.values[5];
    draw_params.data_value = value_int / 100.0;

    k_msgq_put(&draw_msgq, &draw_params, K_NO_WAIT);
  }
  return;
}

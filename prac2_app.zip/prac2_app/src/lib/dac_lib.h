#ifndef DAC_LIB_H
#define DAC_LIB_H

#include <math.h>
#include <zephyr/drivers/dac.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>

// Node for user-specific configuration in the device tree.
#define ZEPHYR_USER_NODE DT_PATH(zephyr_user)

// Conditional inclusion of DAC nodes and properties based on device tree.
#if DT_NODE_HAS_PROP(DT_PATH(zephyr_user), dacs) &&                            \
    DT_PROP_HAS_IDX(DT_PATH(zephyr_user), dacs, 0) &&                          \
    DT_PROP_HAS_IDX(DT_PATH(zephyr_user), dacs, 1)
#define DAC_NODE_1 DT_PHANDLE_BY_IDX(DT_PATH(zephyr_user), dacs, 0)
#define DAC_CHANNEL_ID_1                                                       \
  DT_PROP_BY_IDX(DT_PATH(zephyr_user), dac_channel_ids, 0)
#define DAC_NODE_2 DT_PHANDLE_BY_IDX(DT_PATH(zephyr_user), dacs, 1)
#define DAC_CHANNEL_ID_2                                                       \
  DT_PROP_BY_IDX(DT_PATH(zephyr_user), dac_channel_ids, 1)
#define DAC_RESOLUTION DT_PROP_BY_IDX(DT_PATH(zephyr_user), dac_resolutions, 0)
#else
#error "DAC configuration not found in DeviceTree."
#endif

#define M_PI 3.14f // Math constant PI, used for calculations.

// Maximum DAC value for 12-bit resolution.
#define MAX_VALUE 4094
#define MAX_STRING_LEN 30
#define NUM_STRINGS 10
#define SEGMENT_LENGTH 0.3125f
#define DATA_SIZE 8
// External semaphore for synchronizing data access.
extern struct k_sem button_sem;
// External message queue for drawing commands.
extern struct k_msgq draw_msgq;

// Pointers to DAC device instances.
extern const struct device *dac_dev_1;
extern const struct device *dac_dev_2;

// Enumeration for different types of drawing commands.
typedef enum {
  DRAW_NONE,     // No drawing command.
  DRAW_NUM,   // Command to draw a circle.
  DRAW_METER,    // Command to draw a point.
  DRAW_GRAPH // Command to draw a Lissajous curve.
} draw_command_t;

typedef enum {
  TYPE_AIR,    // No drawing command.
  TYPE_TEMP,   // Command to draw a circle.
  TYPE_HUMID,    // Command to draw a point.
  TYPE_TVOC // Command to draw a Lissajous curve.
} type_command_t;


// Structure to hold parameters for drawing commands.
typedef struct {
  draw_command_t command; // Type of drawing command.
  type_command_t type; // Type of drawing command.
  float data_value;               
  int values[10] ;               
                         
} draw_params_t;

#define MAX_VALUES 10

typedef struct {
    float values[MAX_VALUES]; // Array to store the last 10 sensor values
    int startIndex; // Index of the oldest value
    int count; // Number of values currently stored
} SensorValuesBuffer;

int dac_init();
// Function to configure DAC channel.
// Parameters:
// - dac_dev: Pointer to the DAC device structure.
// - channel_id: DAC channel identifier.
// Returns:
// - 0 on success, error code on failure.
int setup_dac_channel(const struct device *dac_dev, uint8_t channel_id);

// Function to draw a point on a display or graph.
// Parameters:
// - x_val: X-coordinate of the point.
// - y_val: Y-coordinate of the point.
void draw_point(float x_val, float y_val);

// Function to draw a circle on a display or graph.
// Parameters:
// - radius: Radius of the circle.
// - x_offset: X-coordinate of the circle's center.
// - y_offset: Y-coordinate of the circle's center.
void draw_circle(float radius, float x_offset, float y_offset);

// Function to draw meter curve on a display or graph.
// Parameters:
// - x_v: Frequency of the curve along the X-axis.
// - y_w: Frequency of the curve along the Y-axis.
// - phase_shift: Phase shift of the curve.

void draw_meter(float min_value, float max_value, float meter_value);

/**
 * Draws a numerical digit at a specified location.
 * 
 * @param num The number to draw (0-9).
 * @param x The x-coordinate of the location to draw the number.
 * @param y The y-coordinate of the location to draw the number.
 */
void draw_line(float x_start, float y_start, float x_end, float y_end);

/**
 * Draws a series of numbers.
 * 
 * This function iterates through an array of numbers and uses draw_number
 * to render each one at a specific interval along the x-axis.
 *
 * @param numbers The array of numbers to draw.
 * @param count The number of elements in the numbers array.
 */
void draw_series(int numbers[], int count );

/**
 * Draws a graph of values.
 * 
 * Renders a simple line graph based on an array of values. The graph is drawn from right to left.
 *
 * @param values The array of values to graph.
 * @param count The number of elements in the values array.
 */
void draw_graph(float values[], int count );
#endif // DAC_LIB_H

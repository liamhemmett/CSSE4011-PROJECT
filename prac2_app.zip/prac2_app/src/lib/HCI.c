#include "HCI.h"
#include "led_lib.h"
#include <zephyr/device.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/kernel.h>

K_MSGQ_DEFINE(uart_msgq, MSG_SIZE, 10, 4);

static bool got_data = false;

/**
 * Sends a request with the specified data.
 * @param data The data byte to be sent in the request.
 */
void send_request(char *str) {
  int msg_len = strlen(str);

  for (int i = 0; i < msg_len; i++) {
    uart_poll_out(uart_dev, str[i]);
  }

  printk("Device %s sent: \"%s\"\n", uart_dev->name, str);
}

/**
 * Receives a request and returns the received data as a string.
 * @return A pointer to a string containing the received data.
 */
void serial_cb(const struct device *dev, void *user_data) {

  uint8_t c;

  if (!uart_irq_update(uart_dev)) {
    return;
  }

  if (!uart_irq_rx_ready(uart_dev)) {
    return;
  }
  static char rx_buf[MSG_SIZE];
  static int rx_buf_pos = 0;
  /* read until FIFO empty */
  while (uart_fifo_read(uart_dev, &c, 1) == 1) {
	//printk("%c ", c);
    if (c == 0xAA) {

      rx_buf_pos = 0;
      got_data = true;
    } else if ((c == 0x55) && got_data) {
      /* terminate string */

      rx_buf[rx_buf_pos] = '\0';

      /* if queue is full, message is silently dropped */
      k_msgq_put(&uart_msgq, &rx_buf, K_NO_WAIT);
      got_data = false;
      /* reset the buffer (it was copied to the msgq) */
      rx_buf_pos = 0;
    } else if (rx_buf_pos < 40 && got_data) {
      rx_buf[rx_buf_pos++] = c;
    }
  }
}

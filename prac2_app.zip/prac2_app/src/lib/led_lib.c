#include "led_lib.h"

// Initialize gpio_dt_spec for each LED
const struct gpio_dt_spec led0 = GPIO_DT_SPEC_GET(LED0_NODE, gpios);
const struct gpio_dt_spec led1 = GPIO_DT_SPEC_GET(LED1_NODE, gpios);
const struct gpio_dt_spec led2 = GPIO_DT_SPEC_GET(LED2_NODE, gpios);
// Initialize more LEDs as necessary

// Implement toggle functions
void toggle_led0() { gpio_pin_toggle_dt(&led0); }

void toggle_led1() { gpio_pin_toggle_dt(&led1); }

void toggle_led2() { gpio_pin_toggle_dt(&led2); }

int led_init() {

  if (!gpio_is_ready_dt(&led0)) {
    return -1;
  }
  if (!gpio_is_ready_dt(&led1)) {
    return -1;
  }

  if (!gpio_is_ready_dt(&led2)) {
    return -1;
  }

  if (gpio_pin_configure_dt(&led0, GPIO_OUTPUT_INACTIVE) < 0) {
    return -1;
  }
  if (gpio_pin_configure_dt(&led1, GPIO_OUTPUT_INACTIVE) < 0) {
    return -1;
  }
  if (gpio_pin_configure_dt(&led2, GPIO_OUTPUT_INACTIVE) < 0) {
    return -1;
  }
  return 1;
}
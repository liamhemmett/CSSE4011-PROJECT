#ifndef SD_WRITER_H
#define SD_WRITER_H
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/storage/disk_access.h>
#include <zephyr/logging/log.h>
#include <zephyr/fs/fs.h>
#include <ff.h>

#define DISK_DRIVE_NAME "SD"
#define DISK_MOUNT_PT "/"DISK_DRIVE_NAME":"

// The FATFS struct represents the FAT filesystem instance.
extern FATFS fat_fs;

// The fs_mount_t struct contains information about the filesystem mount configuration.
extern struct fs_mount_t mp;

#define MAX_PATH 128

// External reference to the disk mount point string.
extern const char *disk_mount_pt;

/**
 * Initializes the SD card and mounts the filesystem.
 * 
 * This function performs the necessary initializations for the SD card and mounts
 * the filesystem at the predefined mount point. It prepares the system for file
 * operations on the SD card.
 * 
 * @return int Returns 0 on success, and a negative error code on failure.
 */
int sd_card_init(void);

/**
 * Writes a line to a CSV file on the SD card.
 * 
 * Appends a timestamp and a value string to a specified CSV file, creating the file
 * if it does not exist. This function is useful for logging data to the SD card.
 * 
 * @param timestamp The timestamp to write to the CSV line.
 * @param valueStr The value string to write to the CSV line.
 * @param filename The name of the CSV file to append the line to.
 * @return int Returns 0 on success, and a negative error code on failure.
 */
int sd_write_csv_line(uint64_t timestamp, const char* valueStr, const char* filename);

#endif // Ensure to close your header guard if it's part of your header file template.

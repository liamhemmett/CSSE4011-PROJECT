/*
 * Copyright (c) 2019 Tavish Naruka <tavishnaruka@gmail.com>
 * Copyright (c) 2023 Nordic Semiconductor ASA
 * Copyright (c) 2023 Antmicro <www.antmicro.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/* Sample which uses the filesystem API and SDHC driver */

#include "sd_writer.h"
#include <ff.h>
#include <zephyr/device.h>
#include <zephyr/fs/fs.h>
#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>
#include <zephyr/storage/disk_access.h>

FATFS fat_fs;

// Mounting information structure
struct fs_mount_t mp = {
    .type = FS_FATFS,
    .fs_data = &fat_fs,
    .mnt_point = DISK_MOUNT_PT,
};
const char *disk_mount_pt = DISK_MOUNT_PT;

/**
 * Initializes the SD card and mounts the filesystem.
 *
 * This function performs the necessary initializations for the SD card and
 * mounts the filesystem at the predefined mount point. It prepares the system
 * for file operations on the SD card.
 *
 * @return int Returns 0 on success, and a negative error code on failure.
 */
int sd_card_init(void) {
  /* raw disk i/o */

  static const char *disk_pdrv = DISK_DRIVE_NAME;
  uint64_t memory_size_mb;
  uint32_t block_count;
  uint32_t block_size;

  if (disk_access_init(disk_pdrv) != 0) {
    // LOG_ERR("Storage init ERROR!");
    printk("Disk failed.\n");
    return 0;
  }

  if (disk_access_ioctl(disk_pdrv, DISK_IOCTL_GET_SECTOR_COUNT, &block_count)) {
    // LOG_ERR("Unable to get sector count");
    printk("Disk failed.\n");
    return 0;
  }
  // LOG_INF("Block count %u", block_count);

  if (disk_access_ioctl(disk_pdrv, DISK_IOCTL_GET_SECTOR_SIZE, &block_size)) {
    // LOG_ERR("Unable to get sector size");
    printk("Disk failed.\n");
    return 0;
  }
  printk("Sector size %u\n", block_size);

  memory_size_mb = (uint64_t)block_count * block_size;
  printk("Memory Size(MB) %u\n", (uint32_t)(memory_size_mb >> 20));

  mp.mnt_point = disk_mount_pt;

  int res = fs_mount(&mp);
  if (res == FR_OK) {

    printk("Disk mounted.\n");
    return 1;
  }

  printk("Disk failed.\n");
  return 0;
}

/**
 * Writes a line to a CSV file on the SD card.
 *
 * Appends a timestamp and a value string to a specified CSV file, creating the
 * file if it does not exist. This function is useful for logging data to the SD
 * card.
 *
 * @param timestamp The timestamp to write to the CSV line.
 * @param valueStr The value string to write to the CSV line.
 * @param filename The name of the CSV file to append the line to.
 * @return int Returns 0 on success, and a negative error code on failure.
 */
int sd_write_csv_line(uint64_t timestamp, const char *valueStr,
                      const char *filename) {
  struct fs_file_t file;
  int res;
  char path[MAX_PATH];
  char line[100]; // Adjust size as needed

  // Construct the full path
  snprintf(path, sizeof(path), "%s/%s", DISK_MOUNT_PT, filename);

  // Initialize the file struct
  fs_file_t_init(&file);
  printk("%s\n", path);
  // Open or create the CSV file for appending
  res = fs_open(&file, path, FS_O_CREATE | FS_O_APPEND | FS_O_WRITE);
  if (res < 0) {
    // LOG_ERR("Failed to open file %s for writing", path);
    return res;
  }

  // Prepare the line to write, using %s to format the string
  int len = snprintf(line, sizeof(line), "%llu,%s\n", timestamp, valueStr);
  if (len >= sizeof(line)) {
    // LOG_ERR("Line buffer too small");
    fs_close(&file);
    return -ENOMEM;
  }

  // Write the line to the file
  res = fs_write(&file, line, len);
  if (res < len) {
    // LOG_ERR("Failed to write to file %s", path);
    fs_close(&file);
    return -EIO;
  }

  // Close the file
  res = fs_close(&file);
  if (res < 0) {
    // LOG_ERR("Failed to close file %s", path);
    return res;
  }

  return 0; // Success
}
# Graphical Controller Unit (GCU) for Wireless Sensor Monitor Display

## Liam Hemmett - 4697686

### Project Overview

 The project leverages UART for communication between the GCU and the Application Host Unit (AHU), with the graphical output visualized through the Analog Discovery 2 in 'x-y' plot mode for data representation. Data is also saved onto the sd card connected through the ethernet shield.

### Functionality Achieved

#### Graphing

- Enhanced to receive sensor values from the AHU, plotting them as dynamic graphs representing environmental conditions.

#### Meter

- Introduced meter display functionality, mapping sensor values across a semicircular meter for intuitive visual feedback.

#### Numerical Display

- Implemented a numerical display using a seven-segment style font for direct sensor value readout in appropriate units.

#### Data Recording

- Sensor readings are now recorded in a CSV format onto a micro SD card, with filenames set by the AHU for organized data management.

#### Communication Interface

- Utilized UART interface for robust communication between the GCU and AHU, facilitating real-time data transfer and control.

#### IO Control

- Extended control capabilities for RGB LEDs and the user pushbutton to include feedback and interaction based on sensor data.

### Folder Structure

prac2/mycode/prac2_app/src - Source files for GCU firmware.

### References

- Zephyr Project Documentation: [https://docs.zephyrproject.org](https://docs.zephyrproject.org)
- STM32L496G Discovery Board User Manual: [https://www.st.com/resource/en/user_manual/dm00290424.pdf](https://www.st.com/resource/en/user_manual/dm00290424.pdf)
- Analog Discovery 2 Reference Manual

### Installation and Operation Instructions

- **Firmware Flashing:** Flash the provided firmware onto the Nucleo-L496ZG board using the Zephyr project build system.
- **Micro SD Card Preparation:** Format the micro SD card to FAT32 and insert it into the UNO Shield Ethernet Shield W5500 R3 Development board slot.

### User Instructions

- **Graph Viewing:** Connect the Analog Discovery 2 to the DAC outputs of the Nucleo board. Select 'x-y' plot mode on the AD2 software to visualize the sensor data graphs.

- **Data Access:** Retrieve the micro SD card to access recorded sensor data in CSV format. Each file is named according to the sensor data type and timestamp.

